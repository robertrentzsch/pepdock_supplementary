Docking small peptides remains a great challenge: an assessment using AutoDock Vina

Robert Rentzsch* and Bernhard Y. Renard
Research Group Bioinformatics (NG 4), Robert Koch Institute, 13353 Berlin, Germany

*To whom correspondence should be addressed. Email: rentzschr@rki.de 

------------------------------------------------------------------------------------

File S1 � Docking input and preparatory files

- this is a meta-dataset of protein-peptide complexes prepared for re-docking experiments

- the detailed workflow of structure preparation is provided in the paper and supplementary material

- note that the PDB database and all other tools and plugins are referenced in the paper


pdb_raw/         : structures as downloaded from the PDB

pdb_raw_FH/      : the REDUCE 3.23 protonated (and Asn, Gln, His side chain - flipped) versions

pymol_sessions/  : PyMOL 1.6 sessions created based on pdb_raw_FH, respectively

receptors/       : PDB files as saved from PyMOL sessions

ligands/         : PDB files as saved from PyMOL sessions

boxes/           : docking box coordinates as saved from PyMOL sessions using a plugin

receptors_pdbqt/ : generated with MGLTools 1.54 prepare_receptor4.py

ligands_pdbqt/   : generated with MGLTools 1.54 prepare_ligand4.py



