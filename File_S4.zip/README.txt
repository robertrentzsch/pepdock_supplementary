Docking small peptides remains a great challenge: an assessment using AutoDock Vina

Robert Rentzsch* and Bernhard Y. Renard
Research Group Bioinformatics (NG 4), Robert Koch Institute, 13353 Berlin, Germany

*To whom correspondence should be addressed. Email: rentzschr@rki.de 

------------------------------------------------------------------------------------

File S4 - Raw and average results for rigid and flexible docking

- in both subfolders (rigid and flexible docking), there are eight raw results files 
  (one per E-level) and one summary file that links to those

- each raw result file contains the results of five replicate runs for each complex

- the summary file contains the average results for all complexes and E-levels


rigid/        : results for rigid docking with AutoDock Vina
 
flexible/     : results for flexible docking with AutoDock Vina

poses_RD.zip  : the produced RD poses for all E-levels and repruns (multi-pose PDBQT files, each starting with rank 1)

poses_FD.zip  : the produced FD poses for all E-levels and repruns (multi-pose PDBQT files, each starting with rank 1)

The PDBQT files can be loaded into the corresponding PyMOL sessions provided in File S1. The user can then flip through 
all ranks using the left/right arrow keys, starting with rank 1, the top pose.